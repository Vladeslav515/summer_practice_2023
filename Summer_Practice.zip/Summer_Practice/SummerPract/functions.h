#pragma once
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <stdio.h>

#define FILE_NAME "Ukrainian_Rivers.txt"
#define MAX_LINE_LENGTH 100

int extract_length(const char* river_data);
float extract_depth(const char* river_data);
void print_all_rivers(void);
void search_by_length(int target_length);

#endif
